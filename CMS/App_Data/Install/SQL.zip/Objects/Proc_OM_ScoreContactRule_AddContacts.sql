SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_OM_ScoreContactRule_AddContacts]
@ScoreID int,
@RuleID int,
@Value int,
@ContactIDs Type_CMS_OrderedIntegerTable READONLY
AS
BEGIN
SET NOCOUNT ON;

INSERT INTO OM_ScoreContactRule (ScoreID, ContactID, RuleID, Value)
  SELECT @ScoreID, ContactIDs.Value, @RuleID, @Value FROM 
    (SELECT Value FROM @ContactIDs) as ContactIDs
  WHERE ContactIDs.Value NOT IN (SELECT ContactID FROM OM_ScoreContactRule WHERE ScoreID=@ScoreID and ContactID=ContactIDs.Value and RuleID=@RuleID )
END
GO
